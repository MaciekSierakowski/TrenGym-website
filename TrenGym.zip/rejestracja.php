<?php

	session_start();
	
	if (isset($_POST['email']))
	{
		
		$wszystko_OK=true;
        $imie = $_POST['imie'];
        $nazwisko = $_POST['nazwisko'];
        $data_urodzenia = $_POST['urodziny'];
        $numer_tel = $_POST['phone'];
		
		//Sprawdź poprawność loginu
		$login = $_POST['login'];
		
		//Sprawdzenie długości loginu
		if ((strlen($login)<3) || (strlen($login)>20))
		{
			$wszystko_OK=false;
			$_SESSION['e_login']="Login musi posiadać od 3 do 20 znaków!";
		}
		
		if (ctype_alnum($login)==false)
		{
			$wszystko_OK=false;
			$_SESSION['e_login']= "Login moze składać się tylko z liter i cyfr (bez polskich znaków)";
		}
		
		// Sprawdź poprawność adresu email
		$email = $_POST['email'];
		$emailB = filter_var($email, FILTER_SANITIZE_EMAIL);
		
		if ((filter_var($emailB, FILTER_VALIDATE_EMAIL)==false) || ($emailB!=$email))
		{
			$wszystko_OK=false;
			$_SESSION['e_email']="Podaj poprawny adres e-mail!";
		}
		
		//Sprawdź poprawność hasła
		$haslo = $_POST['haslo'];
		
		if ((strlen($haslo)<8) || (strlen($haslo)>20))
		{
			$wszystko_OK=false;
			$_SESSION['e_haslo']="Hasło musi posiadać od 8 do 20 znaków!";
		}
		

		$haslo_hash = password_hash($haslo, PASSWORD_DEFAULT);
			
		
		//Zapamiętaj wprowadzone dane
		$_SESSION['fr_nick'] = $login;
		$_SESSION['fr_email'] = $email;
		
		require_once "connect.php";
		mysqli_report(MYSQLI_REPORT_STRICT);
		
		try 
		{
			$polaczenie = new mysqli($host, $db_user, $db_password, $db_name);
			if ($polaczenie->connect_errno!=0)
			{
				throw new Exception(mysqli_connect_errno());
			}
			else
			{
				//Czy email już istnieje?
				$rezultat = $polaczenie->query("SELECT id FROM uzytkownicy WHERE email='$email'");
				
				if (!$rezultat) throw new Exception($polaczenie->error);
				
				$ile_takich_maili = $rezultat->num_rows;
				if($ile_takich_maili>0)
				{
					$wszystko_OK=false;
					$_SESSION['e_email']="Istnieje już konto przypisane do tego adresu e-mail!";
				}		

				//Czy nick jest już zarezerwowany?
				$rezultat = $polaczenie->query("SELECT id FROM uzytkownicy WHERE login='$login'");
				
				if (!$rezultat) throw new Exception($polaczenie->error);
				
				$ile_takich_nickow = $rezultat->num_rows;
				if($ile_takich_nickow>0)
				{
					$wszystko_OK=false;
					$_SESSION['e_nick']="Podany login juz istnieje Wybierz inny.";
				}
				
				if ($wszystko_OK==true)
				{
                    
					
					if ($polaczenie->query("INSERT INTO uzytkownicy VALUES (NULL, '$imie', '$nazwisko', '$login', '$haslo', '$email', '$data_urodzenia', '$numer_tel', 'Nowy czlonek', 7)"))
					{
						$_SESSION['udanarejestracja']=true;
						header('Location: witaj.php');
					}
					else
					{
						throw new Exception($polaczenie->error);
					}
					
				}
				
				$polaczenie->close();
			}
			
		}
		catch(Exception $e)
		{
			echo '<span style="color:red;">Błąd serwera! Przepraszamy za niedogodności i prosimy o rejestrację w innym terminie!</span>';
			echo '<br />Informacja developerska: '.$e;
		}
		
	}
	
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TrenGym</title>
    <style>
        .error{
            color: red;
            margin-top: 10px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <form method="post">
        Imię: <input type="text" name="imie"><br>
        
        Nazwisko: <input type="text" name="nazwisko"><br>
        Login: <input type="text" name="login"><br>
        <?php
             if(isset($_SESSION['e_login']))
             {
                echo'<div class="error">'.$_SESSION['e_login'].'</div>';
                unset($_SESSION['e_login']);
             }
        ?>
        Email: <input type="text" name="email"><br>
        <?php
             if(isset($_SESSION['e_email']))
             {
                echo'<div class="error">'.$_SESSION['e_email'].'</div>';
                unset($_SESSION['e_email']);
             }
        ?>
        Hasło: <input type="password" name="haslo"><br>
        <?php
             if(isset($_SESSION['e_haslo']))
             {
                echo'<div class="error">'.$_SESSION['e_haslo'].'</div>';
                unset($_SESSION['e_haslo']);
             }
        ?>
        Data urodzenia: <input type="text" name="urodziny"><br>
        Numer telefonu: <input type="number" name="phone"><br>
        <input type="submit" value="Zarejestruj się">
    </form>
    
</body>
</html>
