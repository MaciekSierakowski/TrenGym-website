<?php
  session_start();

  if (!isset($_SESSION["loged"])) 
  {
     header("location: index.php");
     exit();
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TrenGym</title>
</head>
<body>

<?php
   
   echo"Witaj ".$_SESSION['user']."<br>";
   echo'Karnet: '.$_SESSION['karnet']."<br>";
   echo 'Dni do wygaśnięcia: '.$_SESSION['dni_do_wygasniecia']."<br>";
   echo '<a href="logout.php">Wyloguj się</a>'

?>

</body>
</html>