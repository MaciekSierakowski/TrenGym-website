<?php
   session_start();

   if (!isset($_SESSION["succes"]))
   {
     header("Location: index.php");
     exit();
   }
   else
   {
    unset($_SESSION["succes"]);
   }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TrenGym</title>
</head>
<body>
    <p>Udalo ci sie zarejestrowac teraz sie <a href="index.php">zaloguj</a> </p>
</body>
</html>