<?php
   session_start();
   if (isset($_SESSION["loged"]) && $_SESSION["loged"] == "true") 
   {
    header("Location: main.php");
    exit();
   }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TrenGym</title>
</head>
<body>
    <form action="zaloguj.php" method="post">
        Login: <input type="text" name ="login"> <br>
        Hasło: <input type="password" name ="haslo"> <br>
        <input type="submit" value="Zaloguj sie">
    </form>

    <a href="rejestracja.php">rejestracja</a>
    <?php
    if(isset($_SESSION["error"]))
    {
        echo $_SESSION["error"];
    }
        
    ?>
</body>
</html>